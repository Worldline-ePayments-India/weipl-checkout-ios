//
//  Paynimo_JS.h
//  Paynimo_JS
//
//  Created by Mobapp2 on 19/08/19.
//  Copyright © 2019 Tech Process. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Paynimo_JS.
FOUNDATION_EXPORT double weipl_checkoutVersionNumber;

//! Project version string for Paynimo_JS.
FOUNDATION_EXPORT const unsigned char weipl_checkoutVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Paynimo_JS/PublicHeader.h>
